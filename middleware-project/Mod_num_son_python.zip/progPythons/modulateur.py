# paramètres de la modulation
typeMod = "BPSK" # type de modulation possibles = BPSK , QPSK , 8PSK , QAM16 , QAM64
fp=4800 # fréquence de la porteuse en Hz
baud=2400 # débit de symboles
texte ="On n'apprend pas à nager à un canard."
filtreRRC = False # si True, filtrage de i(t) et q(t) avec un filtre à racine cosinus surélevé (Root Raised Cosine)
fEch = 48000 # fréquence d'échantillonnage du signal modulé
bruit100 = 0; # % de bruit rajouté
spectre = False # si True, calcul et affichage du spectre du signal modulé
# paramètres de visualisation
graphe = 3 # si 1, on visualise modulé et porteuse ; si 2 i(t) et q(t) en plus ; si 3 I et Q en plus
diagrammeIQ = True # si True, on visualise le diagramme de constellation

# importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy.io.wavfile import write
from random import randint,seed
import utils

# calcul des signaux
I,Q = utils.texteToSymboles(typeMod,texte)
print("index des symboles émis = ")
print(utils.detectSymboles(typeMod,I,Q))
nSymboles = len(I)
t = np.arange(0.0, nSymboles/baud, 1/fEch)
nEch = int(nSymboles*fEch/baud)
t = t[0:nEch]

signalI = np.zeros(nEch)
signalQ = np.zeros(nEch)
indexSymbole = 0

for i in range(nEch):
    if(not filtreRRC) :
        signalI[i] = I[indexSymbole]
        signalQ[i] = Q[indexSymbole]
    if(i%(fEch/baud)==(fEch/baud-1)) :
        if(filtreRRC) :
            signalI[i] = I[indexSymbole]
            signalQ[i] = Q[indexSymbole]
        indexSymbole+=1

if(filtreRRC) :
    h = utils.rrcosfilter(nEch,0.7,1/baud,fEch)
    signalI = signal.convolve(signalI, h,mode='same')
    signalQ = signal.convolve(signalQ, h,mode='same')

porteuse = np.sin(2*np.pi*fp*t)
porteuseQ = np.cos(2*np.pi*fp*t)
inPhase = signalI*porteuse
quadraturePhase = signalQ*porteuseQ
module = inPhase+quadraturePhase

bruit = np.random.normal(0,bruit100/100,nEch)
module+=bruit

amplitudeMax = max(module)*1.1 # 1.1 pour laisser une marge ... Mystérieux !

dataWav = np.iinfo(np.int16).max * module/amplitudeMax
write("module.wav",fEch,dataWav.astype(np.int16))
with open('paramMod.txt', 'w') as f:
    f.write('type mod = \t' + typeMod)
    f.write('\nfp (Hz) = \t' + str(fp))
    f.write('\nbaud = \t' + str(baud))
    if (filtreRRC) :
        f.write('\nfiltre RRC = Oui')
        f.write('\namplitude = ' + str(amplitudeMax))
    else :
        f.write('\nfiltre RRC = Non')

# représentation graphique des signaux
nMaxAff = 240 # on ne visualise que les nMaxAff premiers échantillons.
if(nEch<nMaxAff):
    nMaxAff = nEch


figMod = plt.figure(num='Modulation',figsize=(8,5))
if (graphe == 1) :
    ax1 = plt.subplot(111)
elif (graphe == 2) :
    ax1 = plt.subplot(211)
elif (graphe == 3) :
    ax1 = plt.subplot(311)

plt.plot(t[0:nMaxAff], module[0:nMaxAff],color = 'black')
plt.plot(t[0:nMaxAff], porteuse[0:nMaxAff],linewidth=0.8,color='gray')
aMax = max(module[0:nMaxAff])
plt.xlim([0, t[nMaxAff-1]])
plt.ylim([-aMax*1.1, aMax*1.1])
plt.grid()
plt.legend(["Modulé", "Porteuse"],loc='lower right')
#plt.title("Modulé et Porteuse")

if(graphe == 2 or graphe == 3) :
    if(graphe == 2) :
        ax2 = plt.subplot(212,sharex=ax1)
    else :
        ax2 = plt.subplot(312,sharex=ax1)
    plt.plot(t, inPhase)
    plt.plot(t, quadraturePhase)
    iqMax = max(inPhase)
    plt.ylim([-iqMax*1.1, iqMax*1.1])
    plt.grid()
    plt.legend(["I(t)", "Q(t)"],loc='lower right')
    #plt.title("I(t) et Q(t)", y=0.96)

if(graphe == 3) :
    ax3 = plt.subplot(313,sharex=ax1)
    plt.plot(t,signalI)
    plt.plot(t,signalQ)
    plt.ylim([-iqMax*1.1, iqMax*1.1])
    plt.grid()
    #plt.title("I et Q", y=0.96)
    plt.xlabel("t en s")
    plt.legend(["I", "Q"],loc='lower right')

figMod.tight_layout()

if (diagrammeIQ) :
    figIQ = plt.figure(num='diagramme IQ',figsize=(4,3))
    utils.move_figure(figIQ,850,100)
    plt.plot(signalI, signalQ,'r.',alpha=0.15)
    plt.ylim([-iqMax*1.1, iqMax*1.1])
    plt.xlim([-iqMax*1.1, iqMax*1.1])
    plt.grid()
    plt.title("diagramme IQ")

if spectre:
    figFFT = plt.figure(num='Spectre',figsize=(4,3))
    utils.move_figure(figFFT,850,400)
    # calcule le spectre du signal
    f_spectre = np.arange(0,fEch,fEch/nEch)
    s_fft = np.fft.fft(module)
    s_module = 2*abs(s_fft)/nEch
    #s_module = utils.moyenneGlissante(s_module,10)
    nMinAff = int((nEch/fEch)*(fp-2.5*baud))
    if (nMinAff<0): nMinAff=0
    nMaxAff = int((nEch/fEch)*(fp+2.5*baud))
    if(nMaxAff>nEch/2) : nMaxAff = nEch/2
    plt.plot(f_spectre[nMinAff:nMaxAff], s_module[nMinAff:nMaxAff])
    plt.grid()

def on_close(event) :
    plt.close("Spectre")
    plt.close("diagramme IQ")
figMod.canvas.mpl_connect('close_event', on_close)
plt.show()
