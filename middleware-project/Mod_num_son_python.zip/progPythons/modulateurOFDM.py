# paramètres de la modulation
typeMod = "QPSK" # type de modulation possibles = BPSK , QPSK , 8PSK , QAM16 , QAM64
fps=[3200,4000,4800,5600,6400] # fréquences des sous porteuses en Hz
baud=800 # débit de symboles par sous porteuse
texte = "On n'apprend pas à nager à un canard." # texte à transmettre
#texte = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
filtreRRC = False # si True, filtrage de i(t) et q(t) avec un filtre à racine cosinus surélevé (Root Raised Cosine)
fEch = 48000 # fréquence d'échantillonnage du signal modulé
bruit100 = 0; # % de bruit rajouté
spectre = True # si True, calcul et affichage du spectre du signal modulé
# paramètres de visualisation
diagrammeIQ = False # si True, on visualise le diagramme de constellation

# importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy.io.wavfile import write
from random import randint,seed
import utils

# calcul des signaux
I,Q = utils.texteToSymboles(typeMod,texte)
print("index des symboles émis = ")
print(utils.detectSymboles(typeMod,I,Q))
nSymboles = len(I)
nSp = len(fps)
t = np.arange(0.0, nSymboles/(baud*nSp), 1/fEch)
nEchSp = int(np.ceil(nSymboles*fEch/(baud*nSp)))
t = t[0:nEchSp]


signalI = np.zeros((nSp,nEchSp))
signalQ = np.zeros((nSp,nEchSp))
module = np.zeros(nEchSp)
indexSymbole = 0
for iSp in range (nSp) :
    for i in range(nEchSp):
        if(not filtreRRC) :
            signalI[iSp][i] = I[indexSymbole]
            signalQ[iSp][i] = Q[indexSymbole]
        if((0*iSp*nEchSp + i)%(fEch/baud)==(fEch/baud-1)) :
            if(filtreRRC) :
                signalI[iSp][i] = I[indexSymbole]
                signalQ[iSp][i] = Q[indexSymbole]
            indexSymbole+=1

    if(filtreRRC) :
        h = utils.rrcosfilter(nEchSp,0.7,1/baud,fEch)
        signalI[iSp] = signal.convolve(signalI[iSp], h,mode='same')
        signalQ[iSp] = signal.convolve(signalQ[iSp], h,mode='same')

    porteuse = np.sin(2*np.pi*fps[iSp]*t)
    porteuseQ = np.cos(2*np.pi*fps[iSp]*t)
    inPhase = signalI[iSp]*porteuse
    quadraturePhase = signalQ[iSp]*porteuseQ
    module += inPhase+quadraturePhase

bruit = np.random.normal(0,bruit100/100,nEchSp)
module+=bruit

amplitudeMax = max(module)*1.1 # 1.1 pour laisser une marge ... Mystérieux !

dataWav = np.iinfo(np.int16).max * module/amplitudeMax
write("module.wav",fEch,dataWav.astype(np.int16))
with open('paramMod.txt', 'w') as f:
    f.write('type mod = \t' + typeMod)
    f.write('\nfps (Hz) = \t' + str(fps))
    f.write('\nbaud = \t' + str(baud))
    if (filtreRRC) :
        f.write('\nfiltre RRC = Oui')
        f.write('\namplitude = ' + str(amplitudeMax))
    else :
        f.write('\nfiltre RRC = Non')

# représentation graphique des signaux
nMaxAff = 240 # on ne visualise que les nMaxAff premiers échantillons.
if(nEchSp<nMaxAff):
    nMaxAff = nEch


figMod = plt.figure(num='Modulation',figsize=(8,5))

ax1 = plt.subplot(111)


plt.plot(t[0:nMaxAff], module[0:nMaxAff],color = 'black')
aMax = max(module[0:nMaxAff])
plt.xlim([0, t[nMaxAff-1]])
plt.ylim([-aMax*1.1, aMax*1.1])
plt.grid()
plt.legend(["Modulé", "Porteuse"],loc='lower right')
#plt.title("Modulé et Porteuse")

figMod.tight_layout()

if (diagrammeIQ) :
    figIQ = plt.figure(num='diagramme IQ',figsize=(4,3))
    utils.move_figure(figIQ,850,100)
    plt.plot(signalI, signalQ,'r.',alpha=0.15)
    plt.ylim([-iqMax*1.1, iqMax*1.1])
    plt.xlim([-iqMax*1.1, iqMax*1.1])
    plt.grid()
    plt.title("diagramme IQ")

if spectre:
    figFFT = plt.figure(num='Spectre',figsize=(4,3))
    utils.move_figure(figFFT,850,400)
    # calcule le spectre du signal
    f_spectre = np.arange(0,fEch,fEch/nEchSp)
    s_fft = np.fft.fft(module)
    s_module = 2*abs(s_fft)/nEchSp
    s_module = utils.moyenneGlissante(s_module,10)
    nMinAff = int((nEchSp/fEch)*(fps[0]-2.5*baud))
    if (nMinAff<0): nMinAff=0
    nMaxAff = int((nEchSp/fEch)*(fps[nSp-1]+2.5*baud))
    if(nMaxAff>nEchSp/2) : nMaxAff = nEchSp/2
    plt.plot(f_spectre[nMinAff:nMaxAff], s_module[nMinAff:nMaxAff])
    plt.grid()

def on_close(event) :
    plt.close("Spectre")
    plt.close("diagramme IQ")
figMod.canvas.mpl_connect('close_event', on_close)
plt.show()
