import utils
import numpy as np
from scipy import signal
from scipy.io.wavfile import write,read
import matplotlib.pyplot as plt
import random

typeMod = "QAM16"
baud = 2400
nEch = 300
fEch = 48000
fp = 4800
texte = "On"

"""
signalI = np.zeros(nEch)

nSymboles = 0
random.seed(0)
for i in range(nEch):
    if(i%(int(fEch/baud))==0):
        signalI[i] = random.randint(0,1)
        nSymboles +=1
"""
# calcul des signaux
I,Q = utils.texteToSymboles(typeMod,texte)
nSymboles = len(I)
t = np.arange(0.0, nSymboles/baud, 1/fEch)
nEch = int(nSymboles*fEch/baud)
t = t[0:nEch]

signalI = np.zeros(nEch)
signalQ = np.zeros(nEch)
indexSymbole = 0

for i in range(nEch):
    if(i%(fEch/baud)==(fEch/baud-1)) :
        signalI[i] = I[indexSymbole]
        signalQ[i] = Q[indexSymbole]
        indexSymbole+=1

h = utils.rrcosfilter(nEch,0.7,1/baud,fEch)
signalIFiltreT = signal.convolve(signalI, h,mode='same')
signalQFiltreT = signal.convolve(signalQ, h,mode='same')
porteuse = np.sin(2*np.pi*fp*t)
porteuseQ = np.cos(2*np.pi*fp*t)
inPhase = signalIFiltreT*porteuse
quadraturePhase = signalQFiltreT*porteuseQ
module = inPhase+quadraturePhase

amplitude = max(module)
"""
dataWav = np.iinfo(np.int16).max * module/amplitude
write("module.wav",fEch,dataWav.astype(np.int16))
fEch,moduleR = read("module.wav")
moduleR = amplitude*moduleR/np.iinfo(np.int16).max
"""
moduleR = module

signalIR = 2*module*porteuse
signalIFiltreR = signal.convolve(signalIR, h,mode='same')/ sum(h)

t = np.arange(0.0, nSymboles/baud, 1/fEch)

fig, ax = plt.subplots()
ax.plot(signalI)
#ax.plot(signalIFiltreT)
ax.plot(signalIFiltreR)
plt.legend(["impulsions", "sortie filtre RC"],loc='lower right')
ax.set(xlabel='n', ylabel='signalI')
ax.grid()

plt.show()
