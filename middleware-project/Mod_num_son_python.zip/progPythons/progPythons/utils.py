import numpy as np
from math import ceil
from matplotlib import get_backend

def rcosfilter(N, beta, Ts, Fs):
    t = (np.arange(N) - N / 2) / Fs
    retour = np.where(np.abs(2*t) == Ts / beta,
        np.pi / 4 * np.sinc(t/Ts),
        np.sinc(t/Ts) * np.cos(np.pi*beta*t/Ts) / (1 - (2*beta*t/Ts) ** 2))
    retour[0:N-1] = retour[1:] # avance d'un échantillon pour synchro ...
    return retour

def rrcosfilter(N, beta, Ts, Fs):
    t = (np.arange(N) - N / 2) / Fs
    retour =np.zeros(len(t))
    for i in range (len(t)):
        if(t[i]==0):
            retour[i] = 1+beta*(4/np.pi - 1)
        elif (np.abs(4*t[i]) == Ts / beta) :
            retour[i] = (beta/np.sqrt(2))*((1+2/np.pi)*np.sin(np.pi/(4*beta)) + (1-2/np.pi)*np.cos(np.pi/(4*beta)))
        else :
            retour[i] = (np.sin(np.pi*(t[i]/Ts)*(1-beta)) + 4*beta*(t[i]/Ts)*np.cos(np.pi*(t[i]/Ts)*(1+beta)))/(np.pi*(t[i]/Ts)*(1-(4*beta*t[i]/Ts)**2))
    retour[0:N-1] = retour[1:] # avance d'un échantillon pour synchro ...
    return retour

def rrcosfilter2(N, alpha, Ts, Fs):
    T_delta = 1/float(Fs)
    time_idx = ((np.arange(N)-N/2))*T_delta
    sample_num = np.arange(N)
    h_rrc = np.zeros(N, dtype=float)
    for x in sample_num:
        t = (x-N/2)*T_delta
        if t == 0.0:
            h_rrc[x] = 1.0 - alpha + (4*alpha/np.pi)
        elif alpha != 0 and t == Ts/(4*alpha):
            h_rrc[x] = (alpha/np.sqrt(2))*(((1+2/np.pi)*(np.sin(np.pi/(4*alpha)))) + ((1-2/np.pi)*(np.cos(np.pi/(4*alpha)))))
        elif alpha != 0 and t == -Ts/(4*alpha):
            h_rrc[x] = (alpha/np.sqrt(2))*(((1+2/np.pi)*(np.sin(np.pi/(4*alpha)))) + ((1-2/np.pi)*(np.cos(np.pi/(4*alpha)))))
        else:
            h_rrc[x] = (np.sin(np.pi*t*(1-alpha)/Ts) + 4*alpha*(t/Ts)*np.cos(np.pi*t*(1+alpha)/Ts))/(np.pi*t*(1-(4*alpha*t/Ts)*(4*alpha*t/Ts))/Ts)
    return h_rrc


def moyenneGlissante(x, N):
    out = np.zeros_like(x, dtype=np.float64)
    dim_len = x.shape[0]
    for i in range(dim_len):
        if N%2 == 0:
            a, b = i - (N-1)//2, i + (N-1)//2 + 2
        else:
            a, b = i - (N-1)//2, i + (N-1)//2 + 1

        #cap indices to min and max indices
        a = max(0, a)
        b = min(dim_len, b)
        out[i] = np.mean(x[a:b])
    return out

def move_figure(f,x,y) :
    backend = get_backend()
    if backend == 'TkAgg':
        f.canvas.manager.window.wm_geometry("+%d+%d" % (x, y))
    elif backend == 'WXAgg':
        f.canvas.manager.window.SetPosition((x, y))
    else:
        f.canvas.manager.window.move(x, y)

def getParamMod() :
    typeMod=''
    fp=-1
    baud=-1
    filtreRRC = False
    amplitude = 1
    sousPorteuse = False
    with open('paramMod.txt') as f:
        lines = f.readlines()
    for l in lines :
        if (l.find('type mod')>=0):
            typeMod = l.rsplit('=',1)[1].strip()
        if (l.find('fp (Hz)')>=0):
            fp = float(l.rsplit('=',1)[1].strip())
        if (l.find('fps (Hz)')>=0):
            s = l.rsplit('=',1)[1].strip()
            s = s[1:-1]
            lst = s.split(',')
            fps = np.array(lst).astype(np.float)
            sousPorteuse = True
        if (l.find('baud')>=0):
            baud = float(l.rsplit('=',1)[1].strip())
        if (l.find('filtre RRC')>=0):
            isFiltre = l.rsplit('=',1)[1].strip()
            if(isFiltre.casefold() == 'Oui'.casefold()) :
                filtreRRC = True
        if (l.find('amplitude')>=0):
            amplitude = float(l.rsplit('=',1)[1].strip())
    if (sousPorteuse) :
        return(typeMod,fps,baud,filtreRRC,amplitude)
    else :
        return(typeMod,fp,baud,filtreRRC,amplitude)

def getSymbole(typeMod) :
    if (typeMod.casefold() == 'BPSK'.casefold()):
        symboles = np.array([[-1,0],[1,0]])
    if (typeMod.casefold() == 'QPSK'.casefold()):
        symboles = np.array([[-0.707,-0.707],[0.707,-0.707],[-0.707,0.707],[0.707,0.707]])
    if (typeMod.casefold() == '8PSK'.casefold()):
        symboles = np.array([
        [0.924,0.383],[0.383,0.924],[-0.924,0.383],[-0.383,0.924],
        [0.924,-0.383],[0.383,-0.924],[-0.924,-0.383],[-0.383,-0.924]
        ])
    if (typeMod.casefold() == 'QAM16'.casefold()):
        racine2 = np.sqrt(2)
        symboles = np.zeros((16,2))
        for iQ in range(4):
            for iI in range(4):
                symboles[iI+iQ*4] = [(2*iI/3-1)/racine2,(2*iQ/3-1)/racine2]
    if (typeMod.casefold() == 'QAM64'.casefold()):
        racine2 = np.sqrt(2)
        symboles = np.zeros((64,2))
        for iQ in range(8):
            for iI in range(8):
                symboles[iI+iQ*8] = [(2*iI/7-1)/racine2,(2*iQ/7-1)/racine2]
    return symboles

def texteToSymboles(typeMod,texte) :
    texte+="\0" # ajouté parce qu'avec le filtre RRC problème sur le dernier symbole
    octets = texte.encode()
    type(octets)
    symboles = getSymbole(typeMod)
    nBitsParSymbole = int(np.log(len(symboles))/np.log(2))
    nSymboles = ceil(8*len(octets)/nBitsParSymbole)
    I = np.zeros(nSymboles)
    Q = np.zeros(nSymboles)
    pos = 0
    buf = 0
    j = 0
    for o in octets :
        for i in range(8):
            val = (o >> (7-i) & 1)
            buf += val*(2**(nBitsParSymbole-pos-1))
            pos+=1
            if(pos==nBitsParSymbole):
                pos=0
                I[j] = symboles[int(buf)][0]
                Q[j] = symboles[int(buf)][1]
                j +=1
                buf=0
    return I,Q

def detectSymboles(typeMod,I,Q):
    symboles = getSymbole(typeMod)
    nSymboles = len(I)
    iSymboles = np.zeros(nSymboles)
    dMinSymbSur2 = ((symboles[0][0]-symboles[1][0])**2 + (symboles[0][1]-symboles[1][1])**2)/4

    for i in range (nSymboles):
        dMinCarre = 99
        iSymbole = 0
        for symbole in symboles : # le plus proche symbole est recherché (distance minimale)
            dCarre = (I[i]-symbole[0])**2 + (Q[i]-symbole[1])**2
            if(dCarre<dMinCarre) :
                dMinCarre = dCarre
                iSymboles[i] = iSymbole
                if(dMinCarre<dMinSymbSur2) : # pour gagner un peu de temps
                    break
            iSymbole+=1
        #print(i,I[i],symboles[int(iSymboles[i])][0],Q[i],symboles[int(iSymboles[i])][1])
    return iSymboles

def iSymbolesToOctets(typeMod,iSymboles) :
    symboles = getSymbole(typeMod)
    nBitsParSymbole = int(np.log(len(symboles))/np.log(2))
    nSymboles = len(iSymboles)
    pos=0
    buf=0
    j=0
    nOctets = ceil(nBitsParSymbole*nSymboles/8)
    octetsDemod = np.zeros(nOctets)
    for iSymbole in iSymboles :
        for i in range(nBitsParSymbole):
            val = (int(iSymbole)>>(nBitsParSymbole-i-1)& 1)
            buf += val*(2**(7-pos))
            pos+=1
            if(pos==8):
                pos=0
                octetsDemod[j] = buf
                j+=1
                buf=0

    #
    return octetsDemod
