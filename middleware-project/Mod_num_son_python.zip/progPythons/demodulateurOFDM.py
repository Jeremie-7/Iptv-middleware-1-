import numpy as np
import utils
import matplotlib.pyplot as plt
from scipy import signal
from scipy.io.wavfile import read

# caractéristiques de la modulation
typeMod,fps,baud,filtreRRC,amplitude = utils.getParamMod()
if(typeMod == '' or len(fps)==0 or baud<=0) :
    print("Impossible de récupérer les paramètres issus du fichier paramètres texte")
else :
    print("type Modulation = " + typeMod)
    print("fp = " + str(fps))
    print("baud = " + str(baud))
    print("filtreRRC = " + str(filtreRRC))
    print("amplitude = " + str(amplitude))
symboles = utils.getSymbole(typeMod)

fEch,module = read("module.wav")
module = amplitude*module/np.iinfo(np.int16).max
nEch = len(module)

nSp = len(fps)
nSymboles = int(baud*nEch/fEch)
t = np.arange(0.0, nEch/fEch, 1/fEch)
t=t[0:len(module)]

iSymboles = np.array([])
for iSp in range (nSp) :
    porteuse = np.sin(2*np.pi*fps[iSp]*t)
    porteuseQ = np.cos(2*np.pi*fps[iSp]*t)
    signalI = module*porteuse
    signalQ = module*porteuseQ
    nEchParSymbole = int(fEch/baud)
    I = np.zeros(nSymboles)
    Q = np.zeros(nSymboles)

    if (filtreRRC) :
        h = utils.rrcosfilter(nEch,0.7,1/baud,fEch)
        signalI = signal.convolve(signalI, h,mode='same')/ sum(h)
        signalQ = signal.convolve(signalQ, h,mode='same')/ sum(h)
        for iSymbole in range(nSymboles):
            I[iSymbole] = signalI[(iSymbole+1)*nEchParSymbole-1]
            Q[iSymbole] = signalQ[(iSymbole+1)*nEchParSymbole-1]
    else :
        for iSymbole in range(nSymboles):
            sumInPhase = 0
            sumQPhase = 0
            for i in range(0,nEchParSymbole) :
                sumInPhase+=signalI[i+iSymbole*nEchParSymbole]
                sumQPhase+=signalQ[i+iSymbole*nEchParSymbole]
            for i in range(0,nEchParSymbole) :
                signalI[i+iSymbole*nEchParSymbole] = sumInPhase/nEchParSymbole
                signalQ[i+iSymbole*nEchParSymbole] = sumQPhase/nEchParSymbole

        for iSymbole in range(nSymboles):
            I[iSymbole] = signalI[int(nEchParSymbole/2)+iSymbole*nEchParSymbole]
            Q[iSymbole] = signalQ[int(nEchParSymbole/2)+iSymbole*nEchParSymbole]

    signalI = signalI * 2
    signalQ = signalQ * 2
    I=I*2
    Q=Q*2

    iSymboles = np.append(iSymboles,utils.detectSymboles(typeMod,I,Q))

octetsDemod = utils.iSymbolesToOctets(typeMod,iSymboles)
try :
    texteDecode = bytearray(octetsDemod.astype('B')).decode()
    print("texte reçu et décodé = ")
    print(texteDecode)
except :
    print("ERREUR. Index des symboles détectés = ")
    print(iSymboles)

# représentation graphique des signaux
nMaxAff = 480 # on ne visualise que les nMaxAff premiers échantillons.
if(nEch<nMaxAff):
    nMaxAff = nEch

figMod = plt.figure(num='Modulation',figsize=(8,5))
ax1 = plt.subplot(211)

plt.plot(t[0:nMaxAff], module[0:nMaxAff],color = 'black')
plt.plot(t[0:nMaxAff], porteuse[0:nMaxAff],linewidth=0.8,color='gray')

aMax = 1
plt.xlim([0, t[nMaxAff-1]])
plt.ylim([-aMax*1.1, aMax*1.1])
plt.grid()
plt.title("Modulé et Porteuse")


ax2 = plt.subplot(212,sharex=ax1)

plt.plot(t,signalI)
plt.plot(t,signalQ)

iqMax = 1
plt.ylim([-iqMax*1.1, iqMax*1.1])
plt.grid()
plt.title("I et Q", y=0.96)
plt.xlabel("t en s")
plt.legend(["I", "Q"],loc='lower right')
for iSymbole in range(nSymboles):
    plt.axvline(x = t[iSymbole*nEchParSymbole], color = 'mistyrose',linewidth=0.8)
figMod.tight_layout()

figIQ = plt.figure(num='diagramme IQ',figsize=(4,3))
utils.move_figure(figIQ,850,100)
plt.plot(signalI, signalQ,'r.',alpha=0.15)
plt.ylim([-iqMax*1.1, iqMax*1.1])
plt.xlim([-iqMax*1.1, iqMax*1.1])
plt.grid()
plt.title("diagramme IQ")

def on_close(event) :
    plt.close("diagramme IQ")

figMod.canvas.mpl_connect('close_event', on_close)
plt.show()
